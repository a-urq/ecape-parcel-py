# SPDX-FileCopyrightText: 2023-present Amelia Urquhart <amelia.r.urquhart@gmail.com>
#
# SPDX-License-Identifier: MIT
__version__ = '1.1.3'
